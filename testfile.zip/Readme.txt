This is the README file for CHAN.
